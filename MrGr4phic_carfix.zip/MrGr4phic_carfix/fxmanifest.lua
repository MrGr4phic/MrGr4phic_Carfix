fx_version 'bodacious'
game 'gta5'

client_script 'mad_client.lua'
server_script 'mad_server.lua'